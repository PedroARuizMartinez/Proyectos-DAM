package persistencia;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JOptionPane;
import model.Botiga;
import principal.GestorBotiguesException;

/**
 *
 * @author fta
 */
public class GestorSerial implements ProveedorPersistencia{
    
    private Botiga botiga;

    public Botiga getBotiga() {
        return botiga;
    }

    public void setBotiga(Botiga botiga) {
        this.botiga = botiga;
    }    

    @Override
    public void desarBotiga(String nomFitxer, Botiga botiga) throws GestorBotiguesException {
        /*
         *TODO
         *
         *Paràmetres: nom del fitxer i botiga
         *
         *Acció:
         * - Ha de desar l'objecte Botiga serialitzat sobre un fitxer del sistema 
         *   operatiu amb nom nomFitxer i extensió ".ser".
         * - Heu de controlar excepcions d'entrada/sortida i en cas de produïrse alguna, 
         *   llavors llançar GestorBotiguesException amb codi GestorSerial.desar 
         *
         *Nota: podeu comprovar que la classe Botiga implementa Serializable  
         *
         *Retorn: cap
         */
        
        try(ObjectOutputStream oos =new ObjectOutputStream(new FileOutputStream(new File(nomFitxer + ".ser")))) {
            oos.writeObject(botiga);
        } catch (IOException ex) {
            throw new GestorBotiguesException("GestorSerial.desar");
        }

    }

    @Override
    public void carregarBotiga(String nomFitxer) throws GestorBotiguesException {
        /*
         *TODO
         *
         *Paràmetres: nom del fitxer
         *
         *Acció:
         * - Ha de carregar el fitxer del sistema operatiu amb nom nomFitxer i extensió 
         *   ".ser" sobre un nou objecte Botiga que es retornarà com a resultat.               
         * - Heu de controlar excepcions d'entrada/sortida i en cas de produïrse alguna, 
         *   llavors llançar GestorBotiguesException amb codi GestorSerial.carrega 
         *
         *Retorn: cap
         */
        
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(nomFitxer + ".ser")))) {
            botiga = (Botiga) ois.readObject();
        } catch (IOException ex) {
            throw new GestorBotiguesException("GestorSerial.carregar");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error de classe: " + ex.getMessage());
        }

    }
}
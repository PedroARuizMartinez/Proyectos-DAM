package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Botiga;
import model.Mestre;
import principal.Component;
import principal.GestorBotiguesException;

/**
 *
 * @author fta
 */
public class GestorJDBC implements ProveedorPersistencia {

    private Botiga botiga;

    private Connection conn; //Connexió a la base de dades

    public Botiga getBotiga() {
        return botiga;
    }

    public void setBotiga(Botiga botiga) {
        this.botiga = botiga;
    }

    /*
     PreparedStatement necessaris
     */

 /*
     * TODO
     *
     * Obtenir una botiga
     * 
     * Sentència select de la taula botigues
     * Columnes: totes
     * Files: la de la botiga el codi de la qual coincideixi amb el passat per paràmetre
     *
     */
    private static String codiBotigaSQL = "SELECT * FROM botigues b WHERE b.codi = ?";

    private PreparedStatement codiBotigaSt;

    /*
     * TODO
     *
     * Afegir una botiga
     * 
     * Sentència per afegir una botiga en la taula botigues
     * Els valors dels camps són els que es passaran per paràmetre
     *
     */
    private static String insereixBotigaSQL = "INSERT INTO botigues(codi, adreca) VALUES (?, ?, ?)";

    private PreparedStatement insereixBotigaSt;

    /*
     * TODO
     *
     * Actualitzar una botiga
     * 
     * Sentència per actualitzar una botiga de la taula botigues
     * Files a actualitzar: la que corresponguin al codi passat per paràmetre
     * Columnes a actualitzar: adreca amb l'altre valor passat per paràmetre
     *
     */
    private static String actualitzaBotigaSQL = " UPDATE botigues SET adreca = ? WHERE codi = ? ";

    private PreparedStatement actualitzaBotigaSt;

    /*
     * TODO
     *
     * Eliminar mestres (donat el codi d'una botiga)
     * 
     * Sentència que elimina els mestres de la taula mestres relacionats amb una botiga
     * Files a eliminar: les que es corresponguin al codi de la botiga passat per paràmetre
     *
     */
    private static String eliminaMestresSQL = " DELETE FROM mestres WHERE botiga = ?";

    private PreparedStatement eliminaMestresSt;

    /*
     * TODO
     *
     * Afegir un mestre
     * 
     * Sentència que afegix un mestre a la taula de mestres
     * Els valors dels camps són els que es passaran per paràmetre
     *
     */
    private static String insereixMestreSQL = "INSERT INTO mestres(nif, nom, sexe, talla) VALUES (?, ?, ?, ?)";

    private PreparedStatement insereixMestreSt;

    /*
     * TODO
     *
     * Seleccionar els mestres d'una botiga
     * 
     * Sentència que selecciona els mestres de la taula mestres d'una botiga determinada
     * Columnes: totes
     * Files: totes les que el codi de la botiga coincideixi amb el passat per paràmetre
     *
     */
    private static String selMestresSQL = " SELECT * FROM mestres WHERE botiga = ?";

    private PreparedStatement selMestresSt;

    /*
     *TODO
     * 
     *Paràmetres: cap
     *
     *Acció:
     *  - Heu d'establir la connexio JDBC amb la base de dades EAC112021S1
     *  - Heu de crear els objectes PrepareStatement declarats com a atributs d'aquesta classe
     *    amb els respectius SQL declarats com a atributs just sobre cadascun d'ells.
     *  - Heu de fer el catch de les possibles excepcions (en aquest mètode no llançarem GestorBotiguesException,
     *    simplement, mostreu el missatge a consola de l'excepció capturada)
     *
     *Retorn: cap
     *
     */
    public void estableixConnexio() throws SQLException {
        String urlBaseDades = "jdbc:derby://localhost:1527/EAC112021S1";
        String usuari = "root";
        String contrasenya = "root123";

        try {
            conn = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
            codiBotigaSt = conn.prepareStatement(codiBotigaSQL);
            insereixBotigaSt = conn.prepareStatement(insereixBotigaSQL);
            actualitzaBotigaSt = conn.prepareStatement(actualitzaBotigaSQL);
            eliminaMestresSt = conn.prepareStatement(eliminaMestresSQL);
            insereixMestreSt = conn.prepareStatement(insereixMestreSQL);
            selMestresSt = conn.prepareStatement(selMestresSQL);
        } catch (SQLException e) {
            conn = null;
            System.out.println(e.getMessage());
            throw e;
        }
    }

    public void tancaConnexio() throws SQLException {
        try {
            conn.close();
        } finally {
            conn = null;
        }
    }

    /*
     *TODO
     * 
     *Paràmetres: el nom del fitxer i la botiga a desar
     *
     *Acció:
     *  - Heu de desar la botiga sobre la base de dades:
     *      - La botiga s'ha de desar a la taula botigues (nomFitxer passat per paràmetre és el codi de la botiga)
     *      - Cada mestre de la botiga, s'ha de desar com a registre de la taula mestres.
     *      - Heu de tenir en compte que si la botiga ja existeix, heu de fer el següent:
     *          - Actualitzar el registre botiga ja existent
     *          - Eliminar tots els mestres d'aquesta botiga de la taula mestres i després inserir els nous com si es tractes
     *            d'una nova botiga.
     *  - Si al fer qualsevol operació es produeix una excepció, llavors heu de llançar l'excepció GestorBotiguesException amb codi "GestorJDBC.desar"
     *
     *Retorn: cap
     *
     */
    @Override
    public void desarBotiga(String nomFitxer, Botiga botiga) throws GestorBotiguesException {

        try {
            if (conn == null) {
                estableixConnexio();
            }

            codiBotigaSt.setInt(1, botiga.getCodi());
            ResultSet registresBotiga = codiBotigaSt.executeQuery();

            if (registresBotiga.next()) { //Existeix la botiga  

                //Actualitzar botiga
                actualitzaBotigaSt.setInt(1, botiga.getCodi());
                actualitzaBotigaSt.setString(2, botiga.getAdreca());
                actualitzaBotigaSt.executeUpdate();

                //Eliminem mestres
                eliminaMestresSt.setInt(1, botiga.getCodi());
                eliminaMestresSt.executeUpdate();

            } else { //La botiga no existeix

                //Actualitzar botiga
                insereixBotigaSt.setInt(1, botiga.getCodi());
                insereixBotigaSt.setString(2, botiga.getAdreca());
                insereixBotigaSt.executeUpdate();
            }

            //Insercio mestres de la botiga
            for (Component component : botiga.getComponents()) {
                if (component != null && component instanceof Mestre) {
                    insereixMestreSt.setString(1, ((Mestre) component).getNif());
                    insereixMestreSt.setString(2, ((Mestre) component).getNom());
                    insereixMestreSt.setString(3, ((Mestre) component).getSexe());
                    insereixMestreSt.setString(4, ((Mestre) component).getTalla());
                    insereixMestreSt.executeUpdate();
                }
            }

            tancaConnexio();

        } catch (SQLException ex) {
            throw new GestorBotiguesException("GestorJDBC.desar");
        }

    }

    /*
     *TODO
     * 
     *Paràmetres: el nom del fitxer de la botiga
     *
     *Acció:
     *  - Heu de carregar la botiga des de la base de dades (nomFitxer passat per paràmetre és el codi de la botiga)
     *  - Per fer això, heu de cercar el registre botiga de la taula amb codi = nomFitxer
     *  - A més, heu d'afegir els mestres a la botiga a partir de la taula mestres
     *  - Si al fer qualsevol operació es dona una excepció, llavors heu de llançar l'excepció GestorBotiguesException 
     *    amb codi "GestorJDBC.carregar"
     *  - Si el nomFitxer donat no existeix a la taula botigues (és a dir, el codi = nomFitxer no existeix), llavors
     *    heu de llançar l'excepció GestorBotiguesException amb codi "GestorJDBC.noexist"
     *
     *Retorn: cap
     *
     */
    @Override
    public void carregarBotiga(String nomFitxer) throws GestorBotiguesException {
        try {

            if (conn == null) {
                estableixConnexio();
            }

            codiBotigaSt.setInt(1, Integer.parseInt(nomFitxer));
            ResultSet registresBotigues = codiBotigaSt.executeQuery();

            // Només hi poden haver 0 o 1 resultats
            if (registresBotigues.next()) {

                botiga = new Botiga(registresBotigues.getInt("codi"), registresBotigues.getString("adreca"));

                //Seleccionem els mestres de la taula mestres i els afegim a la botiga
                selMestresSt.setInt(1, botiga.getCodi());

                ResultSet registresMestres = selMestresSt.executeQuery();

                while (registresMestres.next()) {
                    botiga.addMestre(new Mestre(registresMestres.getString("nif"), registresMestres.getString("nom"), registresMestres.getString("sexe"), registresMestres.getString("talla")));
                }

            } else {
                throw new GestorBotiguesException("GestorJDBC.noExisteix");
            }
            tancaConnexio();

        } catch (SQLException ex) {
            throw new GestorBotiguesException("GestorJDBC.carregar");
        }
    }

}

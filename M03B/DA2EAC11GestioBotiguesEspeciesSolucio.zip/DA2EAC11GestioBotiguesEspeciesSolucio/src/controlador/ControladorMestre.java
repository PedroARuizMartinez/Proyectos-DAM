package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import model.Mestre;
import principal.Component;
import vista.MenuMestre;
import vista.MestreForm;
import vista.MestreLlista;

/**
 *
 * @author fta
 */
public class ControladorMestre implements ActionListener {

    private MenuMestre menuMestre;
    private Mestre mestre = null;
    private MestreForm mestreForm = null;
    private MestreLlista mestreLlista = null;
    private int opcioSelec = 0;

    public ControladorMestre() {

        menuMestre = new MenuMestre();
        afegirListenersMenu();

    }

    private void afegirListenersMenu() {

        for (JButton boto : menuMestre.getMenuButtons()) {
            boto.addActionListener(this);
        }

    }

    private void afegirListenersForm() {

        mestreForm.getbDesar().addActionListener(this);
        mestreForm.getbSortir().addActionListener(this);

    }

    private void afegirListenersLlista() {

        mestreLlista.getbSortir().addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        //Accions per al menú
        JButton[] botons = menuMestre.getMenuButtons();

        for (int i = 0; i < botons.length; i++) {
            if (e.getSource() == botons[i]) {
                menuMestre.getFrame().setVisible(false);
                opcioSelec = i;
                seleccionarOpcio(i);
            }
        }

        //Accions per al formulari de mestres
        if (mestreForm != null) {

            if (e.getSource() == mestreForm.getbDesar()) {

                if (opcioSelec == 1) {//Nou mestre

                    if (!((mestreForm.gettSexe().getText().equals("H")) || (mestreForm.gettSexe().getText().equals("D")))) {
                        JOptionPane.showMessageDialog(menuMestre.getFrame(), "El valor del sexe no és vàlid");
                    } else if (!((mestreForm.gettTalla().getText().equals("S")) || (mestreForm.gettTalla().getText().equals("M")) || (mestreForm.gettTalla().getText().equals("L")) || (mestreForm.gettTalla().getText().equals("XL")))) {
                        JOptionPane.showMessageDialog(menuMestre.getFrame(), "El valor de la talla no és vàlid");
                    } else {
                        ControladorPrincipal.getBotigaActual().getComponents().add(new Mestre(mestreForm.gettNif().getText(), mestreForm.gettNom().getText(), mestreForm.gettSexe().getText(), mestreForm.gettTalla().getText()));
                    }

                } else if (opcioSelec == 2) {//Modificar mestre

                    mestre.setNif(mestreForm.gettNif().getText());
                    mestre.setNom(mestreForm.gettNom().getText());
                    mestre.setSexe(mestreForm.gettSexe().getText());
                    mestre.setTalla(mestreForm.gettTalla().getText());

                    if (!((mestreForm.gettSexe().getText().equals("H")) || (mestreForm.gettSexe().getText().equals("D")))) {
                        JOptionPane.showMessageDialog(menuMestre.getFrame(), "El valor del sexe no és vàlid");
                    } else if (!((mestreForm.gettTalla().getText().equals("S")) || (mestreForm.gettTalla().getText().equals("M")) || (mestreForm.gettTalla().getText().equals("L")) || (mestreForm.gettTalla().getText().equals("XL")))) {
                        JOptionPane.showMessageDialog(menuMestre.getFrame(), "El valor de la talla no és vàlid");
                    }

                }

            } else if (e.getSource() == mestreForm.getbSortir()) { //Sortir

                mestreForm.getFrame().setVisible(false);
                menuMestre.getFrame().setVisible(true);

            }

        }

        if (mestreLlista != null) {

            if (e.getSource() == mestreLlista.getbSortir()) {

                mestreLlista.getFrame().setVisible(false);
                menuMestre.getFrame().setVisible(true);

            }

        }

    }

    private void seleccionarOpcio(Integer opcio) {

        switch (opcio) {
            case 0: //sortir
                ControladorPrincipal.getMenuPrincipal().getFrame().setVisible(true);
                break;
            case 1: // alta
                mestreForm = new MestreForm();
                afegirListenersForm();
                break;
            case 2: // modificar
                int pos = ControladorPrincipal.getBotigaActual().selectComponent(1, seleccionarMestre());
                mestre = (Mestre) ControladorPrincipal.getBotigaActual().getComponents().get(pos);
                mestreForm = new MestreForm(mestre.getNif(), mestre.getNom(), mestre.getSexe(), mestre.getTalla());
                afegirListenersForm();
                break;
            case 3: // llista
                mestreLlista = new MestreLlista();
                afegirListenersLlista();
                break;
        }

    }

    private String seleccionarMestre() {

        int i = 0;

        for (Component component : ControladorPrincipal.getBotigaActual().getComponents()) {

            if (component instanceof Mestre) {
                i++;
            }

        }

        String[] nifs = new String[i];

        i = 0;

        for (Component component : ControladorPrincipal.getBotigaActual().getComponents()) {

            if (component instanceof Mestre) {
                nifs[i] = ((Mestre) component).getNif();
            }

            i++;

        }

        int messageType = JOptionPane.QUESTION_MESSAGE;
        int code = JOptionPane.showOptionDialog(null, "Selecciona un mestre", "Selecció de mestre", 0, messageType, null, nifs, null);

        if (code != JOptionPane.CLOSED_OPTION) {
            return nifs[code];
        }

        return null;
    }
}

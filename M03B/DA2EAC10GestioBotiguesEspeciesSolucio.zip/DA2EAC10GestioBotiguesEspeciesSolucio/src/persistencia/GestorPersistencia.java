package persistencia;

import model.Botiga;
import principal.GestorBotiguesException;

/**
 *
 * @author fta
 */
public class GestorPersistencia {
    private ProveedorPersistencia gestor;

    public ProveedorPersistencia getGestor() {
        return gestor;
    }

    public void setGestor(ProveedorPersistencia pGestor) {
        gestor = pGestor;
    }

    public void desarBotiga(String tipusPersistencia, String nomFitxer, Botiga botiga) throws GestorBotiguesException{
        switch(tipusPersistencia){
            
            case "XML":
                gestor = new GestorXML();
                break;                
            default:
                gestor = new GestorSerial();
                break;
            
        }

        gestor.desarBotiga(nomFitxer, botiga);
    }

    public void carregarBotiga(String tipusPersistencia, String nomFitxer) throws GestorBotiguesException{
       
        switch(tipusPersistencia){
            
            case "XML":
                gestor = new GestorXML();
                break;                
            default:
                gestor = new GestorSerial();
                break;
            
        }

        gestor.carregarBotiga(nomFitxer);
    }
}

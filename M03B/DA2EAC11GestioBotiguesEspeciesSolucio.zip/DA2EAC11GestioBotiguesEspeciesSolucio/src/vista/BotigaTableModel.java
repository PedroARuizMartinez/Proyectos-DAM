package vista;

import controlador.ControladorPrincipal;
import javax.swing.table.AbstractTableModel;
import model.Botiga;

/**
 *
 * @author fta
 */
public class BotigaTableModel extends AbstractTableModel{
    
    private final String[] columnNames = {"Codi", "Adreca"};

    String[][] data = new String[ControladorPrincipal.getMAXBOTIGUES()][2];

    public BotigaTableModel() {
        int i = 0;
        for (Botiga botiga : ControladorPrincipal.getBotigues()) {
            if (botiga != null) {
                data[i][0] = String.valueOf(botiga.getCodi());
                data[i][1] = botiga.getAdreca();
                i++;
            }
        }
    }

    @Override
    public int getRowCount() {
        return data.length;
    }

    @Override
    public int getColumnCount() {
        return data[0].length;
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
    public Object getValueAt(int row, int column) {
        return data[row][column];
    }
    
}

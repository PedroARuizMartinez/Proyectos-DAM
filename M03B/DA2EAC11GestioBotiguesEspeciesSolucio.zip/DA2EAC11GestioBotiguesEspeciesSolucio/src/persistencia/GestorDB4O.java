package persistencia;

import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.query.Predicate;
import model.Botiga;
import principal.GestorBotiguesException;

/**
 *
 * @author fta
 */
public class GestorDB4O implements ProveedorPersistencia {

    private ObjectContainer db;
    private Botiga botiga;

    public Botiga getBotiga() {
        return botiga;
    }

    public void setBotiga(Botiga botiga) {
        this.botiga = botiga;
    }

    /*
     *TODO
     * 
     *Paràmetres: cap
     *
     *Acció:
     *  - Heu de crear / obrir la base de dades "EAC112021S1.db4o"
     *  - Aquesta base de dades ha de permetre que Botiga s'actualitzi en cascada.
     *
     *Retorn: cap
     *
     */
    public void estableixConnexio() {
        EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
        config.common().objectClass(Botiga.class).cascadeOnUpdate(true);
        db = Db4oEmbedded.openFile(config, "EAC112021S2.db4o");
    }

    public void tancaConnexio() {
        db.close();
    }

    /*
     *TODO
     * 
     *Paràmetres: el nom del fitxer i la botiga a desar
     *
     *Acció:
     *  - Heu d'establir la connexio i al final tancar-la.
     *  - Heu de desar l'objecte Botiga passat per paràmetre sobre la base de dades 
     *    (heu d'inserir-la si no existia ja a la base de dades, o actualitzar-la en l'altre cas)
     *  - S'ha de fer la consulta de l'existència amb Predicate
     *
     *Retorn: cap
     *
     */
    @Override
    public void desarBotiga(String nomFitxer, Botiga pBotiga) throws GestorBotiguesException {

        estableixConnexio();
        final int codi = Integer.parseInt(nomFitxer);

        List<Botiga> botigues = db.query(new Predicate<Botiga>() {
            public boolean match(Botiga botiga) {
                return botiga.getCodi() == codi;
            }
        });

        if (botigues.size() != 1) { //No existeix
            db.store(pBotiga);
            db.commit();
        } else { //Existeix
            botiga = botigues.iterator().next();
            botiga.setCodi(pBotiga.getCodi());
            botiga.setAdreca(pBotiga.getAdreca());
            db.store(botiga);
            db.commit();
        }

        tancaConnexio();
    }

    /*
     *TODO
     * 
     *Paràmetres: el nom del fitxer on està guardada la botiga
     *
     *Acció:
     *  - Heu d'establir la connexio i al final tancar-la.
     *  - Heu de carregar la botiga des de la base de dades assignant-la a l'atribut botiga.
     *    Si no existeix, llanceu l'excepció GestorBotiguesException amb codi "GestorDB4O.noExisteix"
     *  - S'ha de fer la consulta amb Predicate
     *
     *Retorn: cap
     *
     */
    @Override
    public void carregarBotiga(String nomFitxer) throws GestorBotiguesException {
        
        estableixConnexio();
        final int codi = Integer.parseInt(nomFitxer);

        List<Botiga> botigues = db.query(new Predicate<Botiga>() {
            public boolean match(Botiga botiga) {
                return botiga.getCodi() == codi;
            }
        });

        if (botigues.size() != 1) { //No existeix
            throw new GestorBotiguesException("GestorDB4O.noExisteix");
        } else {
            botiga = botigues.iterator().next();
        }

        tancaConnexio();
    }
}

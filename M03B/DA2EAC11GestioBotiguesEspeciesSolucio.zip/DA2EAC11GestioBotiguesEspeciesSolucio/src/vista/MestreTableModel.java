package vista;

import controlador.ControladorPrincipal;
import javax.swing.table.AbstractTableModel;
import model.Mestre;
import principal.Component;

/**
 *
 * @author fta
 */
public class MestreTableModel extends AbstractTableModel{
    
    private final String[] columnNames = {"NIF", "Nom", "Sexe", "Talla"};

    String[][] data = new String[ControladorPrincipal.getMAXBOTIGUES()][4];

    public MestreTableModel() {
        int i = 0;
        for (Component component : ControladorPrincipal.getBotigaActual().getComponents()) {
            if (component instanceof Mestre) {
                data[i][0] = ((Mestre)component).getNif();
                data[i][1] = ((Mestre)component).getNom();
                data[i][2] = ((Mestre)component).getSexe();
                data[i][3] = ((Mestre)component).getTalla();
                i++;
            }
        }
    }

    @Override
    public int getRowCount() {
        return data.length;
    }

    @Override
    public int getColumnCount() {
        return data[0].length;
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
    public Object getValueAt(int row, int column) {
        return data[row][column];
    }
    
}

package vista;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author fta
 */
public class MestreForm {

    private JFrame frame;

    private final int AMPLADA = 300;
    private final int ALCADA = 200;

    private JLabel lNif;
    private JTextField tNif;
    private JLabel lNom;
    private JTextField tNom;
    private JLabel lSexe;
    private JTextField tSexe;
    private JLabel lTalla;
    private JTextField tTalla;

    private JButton bDesar;
    private JButton bSortir;

    public MestreForm() {

        //Definició de la finestra del menú
        frame = new JFrame("Formulari Mestre");
        frame.setLayout(new GridLayout(0, 1));

        //Creació dels controls del formulari
        lNif = new JLabel("Nif");
        tNif = new JTextField(8);
        lNom = new JLabel("Nom");
        tNom = new JTextField(20);
        lSexe = new JLabel("Sexe (H per home o D per dona)");
        tSexe = new JTextField(5);
        lTalla = new JLabel("Talla (S, M, L o XL)");
        tTalla = new JTextField(5);

        //Creació dels botons del formulari
        bDesar = new JButton("Desar");
        bSortir = new JButton("Sortir");

        //Addició del tot el formulari a la finestra
        frame.add(lNif);
        frame.add(tNif);
        frame.add(lNom);
        frame.add(tNom);
        frame.add(lSexe);
        frame.add(tSexe);
        frame.add(lTalla);
        frame.add(tTalla);
        frame.add(bDesar);
        frame.add(bSortir);

        //Es mostra la finestra amb propietats per defecte
        frame.setSize(AMPLADA, ALCADA);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public MestreForm(String nif, String nom, String sexe, String talla) {
        this();
        tNif.setText(nif);
        tNom.setText(nom);
        tSexe.setText(sexe);
        tTalla.setText(talla);
    }

    public JFrame getFrame() {
        return frame;
    }

    public void setFrame(JFrame frame) {
        this.frame = frame;
    }

    public JTextField gettNif() {
        return tNif;
    }

    public void settNif(JTextField tNif) {
        this.tNif = tNif;
    }

    public JTextField gettNom() {
        return tNom;
    }

    public void settNom(JTextField tNom) {
        this.tNom = tNom;
    }

    public JTextField gettSexe() {
        return tSexe;
    }

    public void settSexe(JTextField tSexe) {
        this.tSexe = tSexe;
    }

    public JTextField gettTalla() {
        return tTalla;
    }

    public void settTalla(JTextField tTalla) {
        this.tTalla = tTalla;
    }  

    public JButton getbDesar() {
        return bDesar;
    }

    public void setbDesar(JButton bDesar) {
        this.bDesar = bDesar;
    }

    public JButton getbSortir() {
        return bSortir;
    }

    public void setbSortir(JButton bSortir) {
        this.bSortir = bSortir;
    }

}

package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import model.Botiga;
import persistencia.GestorPersistencia;
import vista.MenuPrincipal;

/**
 *
 * @author fta
 */
public class ControladorPrincipal implements ActionListener {

    static private MenuPrincipal menuPrincipal;
    static private final int MAXBOTIGUES = 4;
    static private Botiga[] botigues = new Botiga[MAXBOTIGUES];
    static private int posicioBotigues = 0;
    static private Botiga botigaActual = null;
    static private int tipusElement = 0;
    static private GestorPersistencia gp = new GestorPersistencia();
    //FUTUR static private final String[] METODESPERSISTENCIA = {"XML","Serial","JDBC","DB4O"}; 
    static private final String[] METODESPERSISTENCIA = {"XML", "Serial"};

    public ControladorPrincipal() {
        /*
        TODO
        
        S'inicialitza l'atribut menuPrincipal (això mostrarà el menú principal)
        A cada botó del menú, s'afegeix aquest mateix objecte (ControladorPrincipal) com a listener
        
         */

        menuPrincipal = new MenuPrincipal();

        //S'AFEGEIX EL CONTROLADOR COM A LISTENER DELS BOTONS
        for (JButton boto : menuPrincipal.getMenuButtons()) {
            boto.addActionListener(this);
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        /*
        TODO

        S'ha de cridar a seleccionarOpcio segons l'opció premuda. Penseu que l'opció es 
        correspon amb la posició que el botó ocupa a l'array de botons de menuPrincipal.
        
         */

        JButton[] botons = menuPrincipal.getMenuButtons();
        for (int i = 0; i < botons.length; i++) {
            if (e.getSource() == botons[i]) {
                seleccionarOpcio(i);
            }
        }

    }

    private void seleccionarOpcio(int opcio) {

        switch (opcio) {
            case 0:
                System.exit(0);
                break;
            case 1:
                menuPrincipal.getFrame().setVisible(false);
                ControladorBotiga controladorBotiga = new ControladorBotiga();
                break;
            case 2:
                JOptionPane.showMessageDialog(menuPrincipal.getFrame(), "No heu d'implementar aquest menú");
                break;
        }

    }

    public static MenuPrincipal getMenuPrincipal() {
        return menuPrincipal;
    }

    public static void setMenuPrincipal(MenuPrincipal menuPrincipal) {
        ControladorPrincipal.menuPrincipal = menuPrincipal;
    }

    public static Botiga[] getBotigues() {
        return botigues;
    }

    public static void setBotigues(Botiga[] botigues) {
        ControladorPrincipal.botigues = botigues;
    }

    public static int getPosicioBotigues() {
        return posicioBotigues;
    }

    public static void setPosicioBotigues() {
        ControladorPrincipal.posicioBotigues++;
    }

    public static Botiga getBotigaActual() {
        return botigaActual;
    }

    public static void setBotigaActual(Botiga botigaActual) {
        ControladorPrincipal.botigaActual = botigaActual;
    }

    public static int getTipusElement() {
        return tipusElement;
    }

    public static void setTipusElement(int tipusElement) {
        ControladorPrincipal.tipusElement = tipusElement;
    }

    public static GestorPersistencia getGp() {
        return gp;
    }

    public static void setGp(GestorPersistencia gp) {
        ControladorPrincipal.gp = gp;
    }

    public static int getMAXBOTIGUES() {
        return MAXBOTIGUES;
    }

    public static String[] getMETODESPERSISTENCIA() {
        return METODESPERSISTENCIA;
    }



}

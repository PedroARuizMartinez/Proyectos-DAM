package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import model.Botiga;
import persistencia.GestorDB4O;
import persistencia.GestorJDBC;
import persistencia.GestorPersistencia;
import persistencia.GestorSerial;
import persistencia.GestorXML;
import principal.GestorBotiguesException;
import vista.BotigaForm;
import vista.BotigaLlista;
import vista.MenuBotiga;

/**
 *
 * @author fta
 */
public class ControladorBotiga implements ActionListener {

    private MenuBotiga menuBotiga;
    private BotigaForm botigaForm = null;
    private BotigaLlista botigaLlista = null;
    private int opcioSelec = 0;

    public ControladorBotiga() {

        /*
        TODO
        
        S'inicialitza l'atribut menuBotiga (això mostrarà el menú de botigues)
        Es crida a afegirListenersMenu
        
         */
        menuBotiga = new MenuBotiga();
        afegirListenersMenu();

    }

    //El controlador com a listener dels controls de les finestres que gestionen les botigues
    //S'AFEGEIX EL CONTROLADOR COM A LISTENER DELS BOTONS DEL MENU
    private void afegirListenersMenu() {
        /*
        TODO
        
        A cada botó del menú de botigues, s'afegeix aquest mateix objecte (ControladorBotiga) com a listener
        
         */

        for (JButton boto : menuBotiga.getMenuButtons()) {
            boto.addActionListener(this);
        }

    }

    //S'AFEGEIX EL CONTROLADOR COM A LISTENER DELS BOTONS DEL FORMULARI
    private void afegirListenersForm() {
        /*
        TODO
        
        A cada botó del formulari de la botiga, s'afegeix aquest mateix objecte (ControladorBotiga) com a listener
        
         */

        botigaForm.getDesar().addActionListener(this);
        botigaForm.getSortir().addActionListener(this);

    }

    //S'AFEGEIX EL CONTROLADOR COM A LISTENER DEL BOTO DE LA LLISTA
    private void afegirListenersLlista() {
        /*
        TODO
        
        Al botó de sortir de la llista de botigues, s'afegeix aquest mateix objecte (ControladorBotiga) com a listener
         */

        botigaLlista.getSortir().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        /*
        TODO
        
        Nota:
            Com ControladorBotiga és listener del menú de botigues, del formulari i de la llista, llavors en aquest mètode
            actionPerformed heu de controlar si l'usuari ha premut algun botó de qualsevol dels esmentats frames.
            Ull! En el cas del formulari i de la llista, com provenen del menú (els llança el menú de botigues), heu de verificar
            primer que els objectes botigaForm o botigaLlista no són nulls, per tal de saber si podeu comparar-los amb
            alguns dels botons d'aquests frames.
        
        Accions per al menú:
            S'ha de cridar a seleccionarOpcio segons l'opció premuda. Penseu que l'opció es correspon amb
            la posició que el botó ocupa a l'array de botons de menuBotigues
            També, heu d'actualitzar la propietat opcioSelec (amb l'opció que ha premut l'usuari)
        
        Accions per al formulari de botiga:
            
            ---- DESAR ----
            Si el botó premut per l'usuari és el botó de desar del formulari de botigues, llavors
                Si l'opció seleccionada (al menú de botigues) és 1 (alta), llavors:  
                      - Es crea un nou objecte Botiga amb les dades del formulari.
                      - S'afegeix la botiga creada al vector de ControladorPrincipal
                      - Es posa aquesta botiga com botigaActual (de ControladorPrincipal) i es canvia l'atribut
                        opcioSelec a 2.
                Si l'opció seleccionada (al menú de botigues) és 3 (modificació), llavors:
                      - Es modifica l'objecte boyiga amb les dades del formulari (penseu que és la botigaActual de ControladorPrincipal)
                        Nota: no es validen dades amb aquesta opció (per simplificar)
            ---- SORTIR ----
            Si el botó premut per l'usuari és el botó de sortir del formulari de botigues, llavors:
                      - Heu de tornar al menú de botigues (i amagar el formulari)
        
        Accions per a la llista de botigues:
            
            ---- SORTIR ----
            Si el botó premut per l'usuari és el botó de sortir de la llista de botigues, llavors
                Heu de tornar al menú de botigues (i amagar la llista)
         
         */

        //Accions per al menú
        JButton[] botons = menuBotiga.getMenuButtons();

        for (int i = 0; i < botons.length; i++) {
            if (e.getSource() == botons[i]) {
                menuBotiga.getFrame().setVisible(false);
                opcioSelec = i;
                seleccionarOpcio(i);
            }
        }

        //Accions per al formulari de botigues
        if (botigaForm != null) {

            if (e.getSource() == botigaForm.getDesar()) {

                if (opcioSelec == 1) {//Nova botiga

                    Botiga botiga = new Botiga(botigaForm.gettAdreca().getText());
                    ControladorPrincipal.getBotigues()[ControladorPrincipal.getPosicioBotigues()] = botiga;
                    ControladorPrincipal.setPosicioBotigues();
                    botigaForm.gettCodi().setText(String.valueOf(botiga.getCodi()));
                    ControladorPrincipal.setBotigaActual(botiga);
                    opcioSelec = 2;

                } else if (opcioSelec == 3) {//Modificar botiga

                    ControladorPrincipal.getBotigaActual().setAdreca(botigaForm.gettAdreca().getText());

                }

            } else if (e.getSource() == botigaForm.getSortir()) { //Sortir

                botigaForm.getFrame().setVisible(false);
                menuBotiga.getFrame().setVisible(true);

            }

        }

        if (botigaLlista != null) {

            if (e.getSource() == botigaLlista.getSortir()) {

                botigaLlista.getFrame().setVisible(false);
                menuBotiga.getFrame().setVisible(true);

            }

        }

    }

    private void seleccionarOpcio(Integer opcio) {

        switch (opcio) {

            case 0: //sortir
                ControladorPrincipal.getMenuPrincipal().getFrame().setVisible(true);
                break;

            case 1: // alta
                if (ControladorPrincipal.getPosicioBotigues() < ControladorPrincipal.getMAXBOTIGUES()) {
                    botigaForm = new BotigaForm();
                    botigaForm.gettCodi().setEnabled(false);
                    afegirListenersForm();
                } else {
                    menuBotiga.getFrame().setVisible(true);
                    JOptionPane.showMessageDialog(menuBotiga.getFrame(), "Màxim nombre de botigues assolit.");
                }
                break;

            case 2: //seleccionar
                menuBotiga.getFrame().setVisible(true);
                if (ControladorPrincipal.getBotigues()[0] != null) {
                    seleccionarBotiga();
                } else {
                    JOptionPane.showMessageDialog(menuBotiga.getFrame(), "Abans s'ha de crear al menys una botiga");
                }
                break;

            case 3: //modificar
                if (ControladorPrincipal.getBotigues()[0] != null) {
                    seleccionarBotiga();
                    botigaForm = new BotigaForm(ControladorPrincipal.getBotigaActual().getCodi(), ControladorPrincipal.getBotigaActual().getAdreca());
                    botigaForm.gettCodi().setEnabled(false);
                    afegirListenersForm();
                } else {
                    menuBotiga.getFrame().setVisible(true);
                    JOptionPane.showMessageDialog(menuBotiga.getFrame(), "Abans s'ha de crear al menys una botiga");
                }
                break;

            case 4: // llistar
                if (ControladorPrincipal.getBotigues()[0] != null) {
                    botigaLlista = new BotigaLlista();
                    afegirListenersLlista();
                } else {
                    menuBotiga.getFrame().setVisible(true);
                    JOptionPane.showMessageDialog(menuBotiga.getFrame(), "Abans s'ha de crear al menys una botiga");
                }
                break;

            case 5: //carregar
                /*
            TODO
                
            Es mostra un dialog (JOptionPane.showOptionDialog) amb botons, on cadascun d'ells és un mètode de càrrega 
            (propietat a Controlador Principal: ara XML i Serial)
            Un cop seleccionat el mètode, amb un altre dialog, es demana el codi de la botiga a carregar 
            (recordeu que el nom del fitxer és el codi de la botiga i l'extensió)
            Un cop l'usuari ha entrat el codi i ha premut OK:
                - Es crea un objecte botiga (novaBotiga) com a resultat de cridar al mètode carregarBotiga del gestor de persistència. Penseu que la
                - carrega pots ser d'un fitxer XML o bé d'un fitxer serial.
                - Es comprova si el codi de la novaBotiga ja existeix al vector de botigues (això donarà la posició on s'ha trobat a la llista). Penseu
                que en aquesta classe teniu un mètode per fer la comprovació.
                - Si existeix:
                    - Es mostra un dialog notificant a l'usuari si vol substituir la botiga del vector pel que es carregarà des de el fitxer (JOptionPane.showOptionDialog)
                    - Si l'usuari cancela, no es fa res
                    - Si l'usuari accepta, llavors es posa la nova botiga al vector a la mateixa posició on s'havia trobat aquest codi
                - Si no existeix:
                    - S'afegeix la nova botiga al vector de botigues a la darrera posició
                    - Es mostra un missatge confirmant l'addició (JOptionPane.showMessageDialog)
            
                 */

                menuBotiga.getFrame().setVisible(true);

                int code = JOptionPane.showOptionDialog(null, "Selecciona un mètode", "Carregar botiga", 0, JOptionPane.QUESTION_MESSAGE, null, ControladorPrincipal.getMETODESPERSISTENCIA(), "XML");

                if (code != JOptionPane.CLOSED_OPTION) {

                    GestorPersistencia gestor = new GestorPersistencia();

                    Botiga botiga;

                    try {

                        String codi = JOptionPane.showInputDialog("Quin és el codi de la botiga que vols carregar?");

                        gestor.carregarBotiga(ControladorPrincipal.getMETODESPERSISTENCIA()[code], codi);

                        if (ControladorPrincipal.getMETODESPERSISTENCIA()[code].equals("XML")) {
                            botiga = ((GestorXML) gestor.getGestor()).getBotiga();
                        } else if (ControladorPrincipal.getMETODESPERSISTENCIA()[code].equals("Serial")) {
                            botiga = ((GestorSerial) gestor.getGestor()).getBotiga();
                        } else if (ControladorPrincipal.getMETODESPERSISTENCIA()[code].equals("JDBC")) {
                            botiga = ((GestorJDBC) gestor.getGestor()).getBotiga();
                        } else {
                            botiga = ((GestorDB4O) gestor.getGestor()).getBotiga();
                        }

                        int pos = comprovarBotiga(botiga.getCodi());

                        if (pos >= 0) {

                            Object[] options = {"OK", "Cancel·lar"};
                            int i = JOptionPane.showOptionDialog(null, "Premeu OK per substituir-la.", "Botiga ja existent",
                                    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                                    null, options, options[0]);

                            if (i == 0) {
                                ControladorPrincipal.getBotigues()[pos] = botiga;
                            }

                        } else {

                            ControladorPrincipal.getBotigues()[ControladorPrincipal.getPosicioBotigues()] = botiga;
                            ControladorPrincipal.setPosicioBotigues();
                            JOptionPane.showMessageDialog(menuBotiga.getFrame(), "Botiga afegida correctament");

                        }

                    } catch (GestorBotiguesException e) {
                        JOptionPane.showMessageDialog(menuBotiga.getFrame(), e.getMessage());
                    }
                }

                break;

            case 6: //desar
                /*
                TODO
                
                Es comprova si s'ha seleccionat la botiga, mostrant, si correspon, missatges d'error (JOptionPane.showMessageDialog)
                Si s'ha sseleccionat la botiga:
                    - Es mostra un dialog (JOptionPane.showOptionDialog) amb botons, on cadascun d'ells és un mètode de càrrega
                    (propietat a Controlador Principal: ara XML i Serial)
                    - Un cop escollit el mètode, es desa la botiga cridant a desarBotiga del gestor de persistència.
                 */

                menuBotiga.getFrame().setVisible(true);

                if (ControladorPrincipal.getBotigaActual() != null) {

                    int messageTyped = JOptionPane.QUESTION_MESSAGE;
                    int coded = JOptionPane.showOptionDialog(null, "Selecciona un mètode", "Desar botiga", 0, messageTyped, null, ControladorPrincipal.getMETODESPERSISTENCIA(), "XML");

                    if (coded != JOptionPane.CLOSED_OPTION) {

                        GestorPersistencia gestor = new GestorPersistencia();

                        try {
                            gestor.desarBotiga(ControladorPrincipal.getMETODESPERSISTENCIA()[coded], String.valueOf(ControladorPrincipal.getBotigaActual().getCodi()), ControladorPrincipal.getBotigaActual());
                        } catch (GestorBotiguesException e) {
                            JOptionPane.showMessageDialog(menuBotiga.getFrame(), e.getMessage());
                        }

                    }

                } else {
                    JOptionPane.showMessageDialog(menuBotiga.getFrame(), "Abans s'ha de seleccionar una botiga");
                }

                break;

        }

    }

    private void seleccionarBotiga() {

        String[] codiBotiga = new String[ControladorPrincipal.getPosicioBotigues()];

        int i = 0;

        for (Botiga botiga : ControladorPrincipal.getBotigues()) {

            if (botiga != null) {
                codiBotiga[i] = String.valueOf(botiga.getCodi());
            }

            i++;

        }

        int messageType = JOptionPane.QUESTION_MESSAGE;
        int code = JOptionPane.showOptionDialog(null, "Selecciona una botiga", "Selecció de la botiga", 0, messageType, null, codiBotiga, "A");

        if (code != JOptionPane.CLOSED_OPTION) {
            ControladorPrincipal.setBotigaActual(ControladorPrincipal.getBotigues()[code]);
        }

    }

    private int comprovarBotiga(int codi) {

        boolean trobat = false;

        int pos = -1;

        for (int i = 0; i < ControladorPrincipal.getBotigues().length && !trobat; i++) {

            if (ControladorPrincipal.getBotigues()[i] != null) {
                if (ControladorPrincipal.getBotigues()[i].getCodi() == codi) {
                    pos = i;
                    trobat = true;
                }
            }
        }

        return pos;
    }

}
